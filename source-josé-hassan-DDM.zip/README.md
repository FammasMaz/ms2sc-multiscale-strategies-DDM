`main.m` is the main script to be run.

All other files are stored as functions in `root` and `base` dir.
